package com.problem.swap6_3;

import java.util.Vector;

public class TestEmployeeCollection {
	public static void main(String[] args) {
		Vector<Employee> v1 = addInput();
		display(v1);
	}

	private static Vector<Employee> addInput() {
		// TODO Auto-generated method stub
		Employee e1 = new Employee(101,"Swati","Banglore") ;
		Employee e2 = new Employee(102,"Sourabh","Hyderabad") ;
		Employee e3 = new Employee(103,"sakshil","pune") ;
		Vector<Employee> v = new Vector<Employee>();
		v .add(e1);
		v.add(e2);
		v.add(e3);
		return v;
	}

	private static void display(Vector<Employee> v) {
		// TODO Auto-generated method stub
		for(Employee e:v)
		{
			System.out.println(e.getEmpid()+"\t"+e.getEname()+"\t"+e.getAddress());
		}
	}
	}

