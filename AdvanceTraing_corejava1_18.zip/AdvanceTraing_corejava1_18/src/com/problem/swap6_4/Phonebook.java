package com.problem.swap6_4;

import java.util.ArrayList;
import java.util.List;

public class Phonebook {
	 private List<Contact> phonebook=new ArrayList<Contact>();
	    public void setPhoneBook(List<Contact>obj)
	    {
	        phonebook=obj;
	    }
	    public List<Contact>getPhoneBook()
	    {
	        return phonebook;
	    }
	    public void addContact(Contact contactObj)
	    {
	        phonebook.add(contactObj);
	    }
	    public List<Contact> viewAllContacts()
	    {
	        return phonebook;
	    }
	    public Contact viewContactGivenPhone(long phoneNumber)
	    {
	        Contact obj=new Contact();
	        for(Contact obj1:phonebook)
	        {
	            if(obj1.getPhoneNumber()==phoneNumber)
	            {
	                obj=obj1;
	            }
	        }
	        return obj;
	    }
	    public boolean removeContact(long phoneNumber)
	    {
	        boolean f=false;
	        for(Contact obj:phonebook)
	        {
	            if(obj.getPhoneNumber()==phoneNumber)
	            {
	                f=true;
	                phonebook.remove(obj);
	                break;
	            }
	        }
	        return f;
	    }
	}

