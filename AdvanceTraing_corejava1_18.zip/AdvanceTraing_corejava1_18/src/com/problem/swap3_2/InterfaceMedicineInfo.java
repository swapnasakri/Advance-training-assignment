package com.problem.swap3_2;

public class InterfaceMedicineInfo {

	
	
	public void   displayLabel() {
		  
		System.out.println("Company : CAD Pharma Inc");
		System.out.println("Address : Banglore");
		  
	  }
}
	
	class Tablet extends InterfaceMedicineInfo{
		public void   displayLabel() {
			System.out.println("store in a cool dry place");
			
		}
	}
		
		
		class Syrup extends InterfaceMedicineInfo
		{
		public void displayLabel()
		{
		System.out.println("Consume  as directed by the physician");
		}
		}
		class Ointment extends InterfaceMedicineInfo
		{
		public void displayLabel()
		{
		System.out.println("for external use only");
		}
		
		
	}
	


