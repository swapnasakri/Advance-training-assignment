package com.problem.swap6_1;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Scanner;

public class Student {

	public static void main(String[] args) {
		
		ArrayList<String> stu = new ArrayList<String>();
		int n ;
		Scanner sc = new Scanner (System.in);
		//n=sc.nextInt();
		System.out.println("Enter the number of Student : ");
		n=sc.nextInt();
		for(int i=0 ;i<n;i++)
		{
			stu.add(sc.next()) ;
		}
		System.out.println("Student list :");
		for (String a:stu)
		{
			System.out.println(a);
		}
		System.out.println(" Enter the name of student to be searched : ");
		String str =sc.next();
		int position = Collections.binarySearch(stu, str);
		System.out.println(" Position of "+ str + " is : "+position );
		
		
	}
	}

