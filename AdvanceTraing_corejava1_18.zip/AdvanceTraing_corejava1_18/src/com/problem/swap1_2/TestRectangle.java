package com.problem.swap1_2;

import java.util.Scanner;

public class TestRectangle {
	public static int length;
	public static int breadth;
	public static int area;

	public static void main(String[] args) {
		TestRectangle obj=new TestRectangle();
		Scanner sc=new Scanner(System.in);
		
		System.out.println("enter the length and breadth for rectangle 1: ");
		obj.length=sc.nextInt();
		obj.breadth=sc.nextInt();
		obj.area=length*breadth;
		System.out.println("area of rectangle 1 : "+obj.area);
		
		
		TestRectangle obj1=new TestRectangle();
		System.out.println("enter the length and breadth for rectangle 2: ");
		obj1.length=sc.nextInt();
		obj1.breadth=sc.nextInt();
		obj1.area=length*breadth;
		System.out.println("area of rectangle 2 : "+obj1.area);
		
		
		
		
		TestRectangle obj2=new TestRectangle();
	    System.out.println("enter the length and breadth for rectangle 3: ");
		obj2.length=sc.nextInt();
		obj2.breadth=sc.nextInt();
		obj2.area=length*breadth;
		System.out.println("area of rectangle 3 : "+obj2.area);
		
		
		
		
		TestRectangle obj3=new TestRectangle();
		System.out.println("enter the length and breadth for rectangle 4: ");
		obj3.length=sc.nextInt();
		obj3.breadth=sc.nextInt();
		obj3.area=length*breadth;
		System.out.println("area of rectangle 4 : "+obj3.area);
		
		
		
		TestRectangle obj4=new TestRectangle();
		System.out.println("enter the length and breadth for rectangle 5: ");
		obj4.length=sc.nextInt();
		obj4.breadth=sc.nextInt();
		obj4.area=length*breadth;
		System.out.println("area of rectangle 5 : "+obj4.area);
		
		
	}

}
