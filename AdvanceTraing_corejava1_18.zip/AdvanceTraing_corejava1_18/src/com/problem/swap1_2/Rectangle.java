package com.problem.swap1_2;

public class Rectangle {
	public int length;
	public int breadth;
	public int area;
	
	
	public Rectangle() {
		
	}
	//constructor
	public Rectangle(int length,int breadth) {
		this.length=length;
		this.breadth=breadth;
	}

	
	
	public void calculatrArea() {
		area=length*breadth;
		System.out.println("Area of Rectangle : " + area);
	}
	
	public void display() {
		System.out.println("length of Rectangle : " + length);
		System.out.println("breadth of Rectangle : " + breadth);
		System.out.println("Area of Rectangle : " + area);
	}

}
