package com.problem.swap3_1;

public abstract class AbsractDemoclass {

	public abstract void play() ;

	

}
