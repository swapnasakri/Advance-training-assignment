package com.problem.swap1_1;

import java.util.Scanner;

public class EvenDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
int n=0,i=0;
Scanner X=new Scanner(System.in);
System.out.println("enter the value of n: ");
n=X.nextInt();
for(i=0;i<=n;i++)
{
	if(i%2==0) {
		System.out.println(i+ " ");
	}
}

	}

}
